package es.redmetro.dam2.dao;

public interface ILineaDao {
}
