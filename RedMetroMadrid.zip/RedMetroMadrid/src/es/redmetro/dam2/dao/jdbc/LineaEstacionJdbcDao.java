package es.redmetro.dam2.dao.jdbc;

import es.redmetro.dam2.dao.ILineaEstacionDao;

public class LineaEstacionJdbcDao implements ILineaEstacionDao {

}
