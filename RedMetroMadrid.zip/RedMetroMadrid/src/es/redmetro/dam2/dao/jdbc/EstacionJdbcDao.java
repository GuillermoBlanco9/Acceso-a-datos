package es.redmetro.dam2.dao.jdbc;

import es.redmetro.dam2.dao.IEstacionDao;

public class EstacionJdbcDao implements IEstacionDao{
}
