package es.redmetro.dam2.dao.jdbc;

import es.redmetro.dam2.dao.IColorDao;

public class ColorJdbcDao implements IColorDao{
}
