package es.redmetro.dam2.dao.jdbc;

import es.redmetro.dam2.dao.ITrenDao;

public class TrenJdbcDao implements ITrenDao{
}
