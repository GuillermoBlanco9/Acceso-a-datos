package es.redmetro.dam2;

import java.util.List;

import es.redmetro.dam2.dao.ICocheraDao;
import es.redmetro.dam2.dao.jdbc.CocheraJdbcDao;
import es.redmetro.dam2.procesos.ProcesoFicheros;
import es.redmetro.dam2.vo.Cochera;

public class AppRedMetro {
	public static void main(String[] args) {
		ProcesoFicheros procesador = new ProcesoFicheros();

		// Procesar fichero CSV
		procesador.procesarFicheroCocherasCSV();
		
		ICocheraDao operacionesCochera =new CocheraJdbcDao();
		// Consulta de Cocheras que contienen
		List<Cochera> cocheras = operacionesCochera.consultarCocherasContieneTextoDireccion("IDA") ;
		System.out.println(cocheras.size());
		
		procesador.crearXMLCocheras(cocheras);
	}
}

