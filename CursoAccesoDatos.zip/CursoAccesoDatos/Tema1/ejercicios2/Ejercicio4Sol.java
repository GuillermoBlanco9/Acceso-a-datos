package ejercicios2;

import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.WRITE;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *  @descrition Soluci�n Ejercicio 4
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio4Sol {

	/**
	 * M�todo que solicita un nombre de archivo
	 * 
	 * @return el nombre de archivo si existe, sino finaliza el programa
	 */
	public Path getNombre(Scanner escaner) {
		String nombreArchivo = "";

		System.out
				.println("Introduce un nombre de archivo donde almacenar las frases");

		nombreArchivo = escaner.nextLine();
		Path p2 = Paths.get(nombreArchivo);
		try {

			Path fp = p2.toRealPath();

			System.out.println("Path real " + fp);
		} catch (NoSuchFileException x) {

			System.err.format("%s: no existe" + " el fichero o directorio %n",
					p2);
			System.exit(-1);
		} catch (IOException x) {

			System.err.format("%s%n", x);
			System.exit(-1);

		}
		return p2;

	}

	/**
	 * M�todo que solicita frases al usuario
	 * @param escaner
	 * @return
	 */
	public List<String> getFrases(Scanner escaner) {
		List<String> fileLista = new ArrayList<String>();

		String entrada = "";
		do {

			System.out
					.println("Por favor introduzca una cadena por teclado o <Enter> para finalizar");
			entrada = escaner.nextLine();
			fileLista.add(entrada);

		} while (entrada.length() > 0);

		return fileLista;
	}

	/**
	 * M�todo que escribe frases a un archivo
	 * @param cadenas
	 * @param ruta
	 */
	public void escribefrase(String cadena, Path ruta) {

		Charset charset = Charset.forName("UTF-8");
		OpenOption[] options = new OpenOption[2];
		options[0] = APPEND;
		options[1] = WRITE;

		try (BufferedWriter writer = Files.newBufferedWriter(ruta, charset,
				options)) {
			writer.write(cadena, 0, cadena.length());
			writer.newLine();

		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
			System.exit(-1);
		}
	}

	public static void main(String[] args) {
		Scanner escaner = new Scanner(System.in);
		Ejercicio4Sol ejer = new Ejercicio4Sol();
		Path archivo = ejer.getNombre(escaner);
		int i;
		List<String> fileLista = ejer.getFrases(escaner);
		if (fileLista.size() > 0) {
			for (i = 0; i < fileLista.size(); i++) {
				ejer.escribefrase(fileLista.get(i), archivo);
			}
		}
		escaner.close();

	}

}
