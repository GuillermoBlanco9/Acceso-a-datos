/**
 *Aula.java
 *@author Laura Lozano
 *@version 1.0
 */

package ejercicios2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 *  @descrition Soluci�n Aula para el Ejercicio 7
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class AulaSol7 {
	private List<Alumno> alumnos;
	private int numalumnos; // atributo para controlar el n�mero real de
							// elementos que tiene nuestro almac�n

	/**
	 * Constructor del Almac�n con un determinado tamano
	 * 
	 * @param tamano
	 */
	public AulaSol7(int tamano) {
		alumnos = new ArrayList<Alumno>(tamano);
		numalumnos = tamano;

	}

	/**
	 * Comprueba si el almac�n est� vacio
	 * 
	 * @return true si est� vacio
	 */
	public boolean estaVacio() {
		return alumnos.isEmpty();
	}

	/**
	 * Comprueba si el almac�n est� lleno
	 * 
	 * @return
	 */
	public boolean estaLLeno() {
		return numalumnos == alumnos.size();
	}

	/**
	 * Anade un nuevo elemento al almac�n si hay sitio
	 * 
	 * @param valor
	 *            a anadir al almac�n
	 */
	public void add(Alumno alumno) {
		if (!this.estaLLeno()) {
			alumnos.add(alumno);
			
		}
	}

	/**
	 * Elimina un elemento del almac�n si est� en el almacen
	 * 
	 * @param valor
	 * @return true si elimina el elemento, false en caso contrario
	 */
	public boolean eliminar(Alumno alumno) {
		return alumnos.remove(alumno);

	}

	/**
	 * Imprime por pantalla los elementos del almac�n
	 */
	public void informacionAlumnos() {
		System.out.println("El aula tiene los siguientes alumnos:");
		for (int j = 0; j < alumnos.size(); j++) {
			System.out.println(alumnos.get(j).toString() + " ");
		}
	}

	/**
	 * M�todo que escribe los alumnos en un archivo
	 * 
	 * @param ruta
	 */
	public void escribeAlumnos(Path ruta)  {

		int i;
		Charset charset = Charset.forName("UTF-8");
		
		try (BufferedWriter writer = Files.newBufferedWriter(ruta, charset)) {
			for (i = 0; i < alumnos.size(); i++) {
				writer.write(alumnos.get(i).toString());
				if (i<alumnos.size()-1) writer.newLine();
							
			}
			writer.close();
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
			
		}

	}

	/**
	 * M�todo que lee alumnos de un archivo y los muestra por pantalla
	 * 
	 * @param ruta
	 */
	public void leeAlumnos(Path ruta) {

		Charset charset = Charset.forName("UTF-8");
		BufferedReader reader = null;
		try {
			reader = Files.newBufferedReader(ruta, charset);
			String line = null;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
			if (reader != null) {
				reader.close();
			}
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
			
		}
	}

}
