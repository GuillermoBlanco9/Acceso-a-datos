package ejercicios2;


import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *  @descrition Soluci�n Ejercicio 7 y 8
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio78Sol {
	
	public static final int NUM_ALUMNOS=2;

	public static void main(String[] args) {
		Scanner escaner = new Scanner(System.in);
		String nombreArchivo = "";
		//Laura: Para la soluci�n del ejercicio 8 cambiar AulaSol7 por AulaSol8 en la siguiente l�nea
		AulaSol7 aula=new AulaSol7(NUM_ALUMNOS);
		String nombre="";
		String apellidos="";
		String calle="";
		int ano;		
		int numero;
		
		System.out
				.println("Introduce un nombre de archivo donde almacenar los alumnos");
		nombreArchivo = escaner.nextLine();

		System.out.println("nombre de archivo es:" + nombreArchivo);
		Path ruta = Paths.get(nombreArchivo);
		if (Files.exists(ruta)) {
			System.out.println("el archivo ya existe");
			System.exit(-1);
		}
		for (int i=0;i<NUM_ALUMNOS;i++){
			
			System.out.println("Por favor introduzca un nombre de alumno");
			nombre=escaner.nextLine();
			System.out.println("Por favor introduzca los apellidos del alumno");
			apellidos=escaner.nextLine();
			System.out.println("Por favor introduzca el a�o de nacimiento del alumno");
			ano=escaner.nextInt();
			//Colocamos el escaner en la siguiente l�nea
			escaner.nextLine();
			System.out.println("Por favor introduzca el nombre de la calle del alumno");
			calle=escaner.nextLine();
			System.out.println("Por favor introduzca el n�mero de la calle del alumno");
			numero=escaner.nextInt();
			escaner.nextLine();
			aula.add(new Alumno(nombre,apellidos,ano,calle,numero));
			
			
		} 
		escaner.close();
		
		aula.escribeAlumnos(ruta);
		aula.leeAlumnos(ruta);

	}

}
