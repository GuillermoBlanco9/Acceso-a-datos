package ejercicios2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *  @descrition Soluci�n Ejercicio 6-3 y 6-4
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio634Sol {
	
	/**
	 * M�todo que solicita un nombre de archivo
	 * 
	 * @return el nombre de archivo si existe, sino finaliza el programa
	 */
	public Path getNombre(Scanner escaner) {
		String nombreArchivo="";
		
		System.out.println("Introduce un nombre de archivo donde almacenar las frases");
		
		nombreArchivo = escaner.nextLine();
		Path p2 = Paths.get(nombreArchivo);
		try {

			Path fp = p2.toRealPath();	

			System.out.println("Path real " + fp);
		} catch (NoSuchFileException x) {

			System.err.format("%s: no existe" + " el fichero o directorio %n",
					p2);
			System.exit(-1);
		} catch (IOException x) {

			System.err.format("%s%n", x);
			System.exit(-1);

		}
		return p2;

	}

	/**
	 * M�todo que solicita frases al usuario
	 * @param escaner
	 * @return
	 */
	public List<String> getFrases(Scanner escaner) {
		List<String> fileLista = new ArrayList<String>();
		
		String entrada="";
		do {
			
			System.out.println("Por favor introduzca una cadena por teclado o <Enter> para finalizar");
			entrada=escaner.nextLine();
			fileLista.add(entrada);
			
		} while (entrada.length() > 0);
		
		return fileLista;
	}

	/**
	 * M�todo que escribe frases a un archivo
	 * @param cadenas
	 * @param ruta
	 */
	public void escribefrases(List<String> cadenas, Path ruta) {
		
		int i;
		Charset charset = Charset.forName("UTF-8");
		try (BufferedWriter writer = Files.newBufferedWriter(ruta, charset)) {
			for (i = 0; i < cadenas.size(); i++) {
				writer.write(cadenas.get(i), 0, cadenas.get(i).length());
				//Escribimos nueva l�nea para separarlas
				if (i<cadenas.size()-1) writer.newLine();
			}
		    
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		    System.exit(-1);
		}

	}
	
	/**
	 * M�todo que lee frases de un archivo y las muestra por pantalla
	 * @param cadenas
	 * @param ruta
	 */
	public void leerFrases(Path ruta) {
	
		Charset charset = Charset.forName("UTF-8");
		BufferedReader reader=null;
		try{
			reader = Files.newBufferedReader(ruta, charset);		
		    String line = null;
		    while ((line = reader.readLine()) != null) {
		        System.out.println(line);
		    }
		    if (reader != null) {
                reader.close();
            }
		} catch (IOException x) {
		    System.err.format("IOException: %s%n", x);
		}
	}


	public static void main(String[] args) {
		Scanner escaner = new Scanner(System.in);
		Ejercicio634Sol ejer = new Ejercicio634Sol();
		Path archivo = ejer.getNombre(escaner);
		List<String> fileLista = ejer.getFrases(escaner);
		if (fileLista.size() > 0) {
			ejer.escribefrases(fileLista, archivo);
		}
		ejer.leerFrases(archivo);
		escaner.close();


	}

}
