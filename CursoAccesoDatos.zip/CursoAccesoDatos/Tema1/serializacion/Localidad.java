package serializacion;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @descrition
 * @author Laura
 * @date 7/4/2015
 * @version 1.0
 * @license GPLv3
 */

/*
 * Si os fij�is usamos 3 anotaciones: XmlRootElement, XmlType y XmlElement.
 * 
 * La primera marca el elemento ra�z de nuestra clase (en nuestro caso el nombre
 * de la clase).Con XmlType y la propiedad �propOrder� cambiamos el orden en que
 * se escribir�n los atributos en el xml resultante.Finalmente usando XmlElement
 * en el setter de los atributos que nos interesa que se incluyan en el xml,
 * marcamos los campos de nuestro inter�s.
 */
@XmlRootElement
@XmlType(propOrder = { "cp", "nombre" })
class Localidad {
	private String nombre;
	private int cp;

	public String getNombre() {
		return nombre;
	}

	@XmlElement
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCp() {
		return cp;
	}

	@XmlElement
	public void setCp(int cp) {
		this.cp = cp;
	}
}
