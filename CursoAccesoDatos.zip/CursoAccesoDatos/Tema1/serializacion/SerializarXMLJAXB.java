package serializacion;

/**
 *  @descrition Serializando XML de manera directa con JAXB
 *	@author Laura
 *  @date 7/4/2015
 *  @version 1.0
 *  @license GPLv3
 */


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class SerializarXMLJAXB {
	private static final String PROVINCIA_DAT_FILE = "provincia.xml";

	public static void main(String[] args) throws JAXBException, IOException {
		JAXBContext context = JAXBContext.newInstance(Provincia.class);
		Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		Provincia provincia = fillProvincia();
		// Mostramos el documento XML generado por la salida estandar
		marshaller.marshal(provincia, System.out);
		// guardamos el objeto serializado en un documento XML
		marshaller.marshal(provincia, Files.newOutputStream(Paths.get(PROVINCIA_DAT_FILE)));
		//fos.close();
		Unmarshaller unmarshaller = context.createUnmarshaller();
		// Deserealizamos a partir de un documento XML
		Provincia provincaAux = (Provincia) unmarshaller.unmarshal(Files.newInputStream(Paths.get(
				PROVINCIA_DAT_FILE)));
		System.out
				.println("********* Provincia cargado desde fichero XML***************");
		// Mostramos por linea de comandos el objeto Java obtenido
		// producto de la deserialziacion
		marshaller.marshal(provincaAux, System.out);
	}

	private static Provincia fillProvincia() {
		String[] nombreLocalidad = { "Madrid", "Coslada" };
		int[] cpLocalidad = { 28028, 28820 };
		Localidad[] localidades = new Localidad[2];
		for (int i = 0; i < 2; i++) {
			localidades[i] = new Localidad();
			localidades[i].setCp(cpLocalidad[i]);
			localidades[i].setNombre(nombreLocalidad[i]);
		}
		Provincia provincia = new Provincia();
		provincia.setNombre("Madrid");
		provincia.setLocalidad(localidades);
		return provincia;
	}

}
