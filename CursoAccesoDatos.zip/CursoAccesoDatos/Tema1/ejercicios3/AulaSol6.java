/**
 *Aula.java
 *@author Laura Lozano
 *@version 1.0
 */

package ejercicios3;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class AulaSol6 {
	private List<Alumno> alumnos;
	private int numalumnos; // atributo para controlar el n�mero real de
							// elementos que tiene nuestro almac�n

	/**
	 * Constructor del Almac�n con un determinado tamano
	 * 
	 * @param tamano
	 */
	public AulaSol6(int tamano) {
		alumnos = new ArrayList<Alumno>(tamano);
		numalumnos = tamano;

	}

	/**
	 * Comprueba si el almac�n est� vacio
	 * 
	 * @return true si est� vacio
	 */
	public boolean estaVacio() {
		return alumnos.isEmpty();
	}

	/**
	 * Comprueba si el almac�n est� lleno
	 * 
	 * @return
	 */
	public boolean estaLLeno() {
		return numalumnos == alumnos.size();
	}

	/**
	 * Anade un nuevo elemento al almac�n si hay sitio
	 * 
	 * @param valor
	 *            a anadir al almac�n
	 */
	public void add(Alumno alumno) {
		if (!this.estaLLeno()) {
			alumnos.add(alumno);

		}
	}

	/**
	 * Elimina un elemento del almac�n si est� en el almacen
	 * 
	 * @param valor
	 * @return true si elimina el elemento, false en caso contrario
	 */
	public boolean eliminar(Alumno alumno) {
		return alumnos.remove(alumno);

	}

	/**
	 * Imprime por pantalla los elementos del almac�n
	 */
	public void informacionAlumnos() {
		System.out.println("El aula tiene los siguientes alumnos:");
		for (int j = 0; j < alumnos.size(); j++) {
			System.out.println(alumnos.get(j).toString() + " ");
		}
	}

	/**
	 * M�todo que escribe los alumnos en un archivo
	 * 
	 * @param ruta
	 */
	public void escribeAlumnos(Path ruta) {

		int i;
		try {
			// Creamos el archivo
			// InputStream y OutputStream de java.io nos permiten trabajar byte
			// a byte
			OutputStream ostream = Files.newOutputStream(ruta);
			// FileOutputStream fs = new FileOutputStream("agenda.txt");
			ObjectOutputStream os = new ObjectOutputStream(ostream);
			// El m�todo writeObject() serializa el objeto y lo escribe en el
			// archivo
			for (i = 0; i < alumnos.size(); i++) {
				os.writeObject(alumnos.get(i));
			}

			os.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * M�todo que lee alumnos de un archivo y los muestra por pantalla
	 * 
	 * @param ruta
	 */
	public void leeAlumnos(Path ruta) {

		Alumno a2 = null;

		try {
			InputStream istream = Files.newInputStream(ruta);
			ObjectInputStream os = new ObjectInputStream(istream);

			// El m�todo readObject() recupera el objeto
			while (istream.available() > 0){
				a2 = (Alumno) os.readObject();
				System.out.println(a2.toString());
			}
			os.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
