package ejercicios3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 * @descrition Soluci�n del ejercicio 8
 * @author Laura
 * @date 7/4/2015
 * @version 1.0
 * @license GPLv3
 */

public class Ejercicio8Sol {
	private static final String DAT_FILE = "empleados.xml";

	public static void main(String[] args) throws JAXBException, IOException {

		long time = System.currentTimeMillis();
		System.out.println("Inicio: " + new Date(time));
		Empresa cc = new Empresa();
		cc.setIdEmpresa(1);
		cc.setDireccion("En la nube");
		cc.setNombreEmpresa("IES");
		cc.setNumEmpleados(10);

		ArrayList<Empleado> alCU = new ArrayList<Empleado>();
		int init = 20000;
		for (int i = 1; i < 10; i++) {
			Empleado cu = new Empleado();
			cu.setId(i);
			cu.setActivo(true);
			cu.setNumeroEmpl(new Integer(init++));
			cu.setNombre("Empleado " + i);
			cu.setTitulo("SW Architect");
			cu.setFechaAlta(new Date(System.currentTimeMillis()));

			alCU.add(cu);
		}

		cc.setEmpleados(alCU);

		JAXBContext context = JAXBContext.newInstance(Empresa.class);
		// Si las clases a serializar est�n en otro paquete se indica el paquete
		// al crear el marshall
		Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		// Provincia provincia = fillProvincia();
		// Mostramos el documento XML generado por la salida estandar
		marshaller.marshal(cc, System.out);
		// guardamos el objeto serializado en un documento XML
		marshaller.marshal(cc, Files.newOutputStream(Paths.get(DAT_FILE)));
		Unmarshaller unmarshaller = context.createUnmarshaller();
		// Deserealizamos a partir de un documento XML
		Empresa empresa = (Empresa) unmarshaller.unmarshal(Files.newInputStream(Paths.get(DAT_FILE)));
		System.out
				.println("********* Empresa cargado desde fichero XML***************");
		// Mostramos por linea de comandos el objeto Java obtenido
		// producto de la deserialziacion
		marshaller.marshal(empresa, System.out);

	}
}
