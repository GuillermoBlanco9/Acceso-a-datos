package ejercicios3;

import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

/**
 * @descrition Soluci�n del Ejercicio 7 utilizando el API DOM
 * @author Laura
 * @date 7/4/2015
 * @version 1.0
 * @license GPLv3
 */

public class Ejercicio7aSol {

	public static void main(String[] args) {
		String nombre_archivo = "Alumno7DOM.xml";
		Alumno7 alumno = new Alumno7("pepe", "garcia", 1978, "calle alegria,5");

		try {
			generate(nombre_archivo, alumno);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void generate(String archivo, Alumno7 alumno) throws Exception {

		if (alumno==null) {
			System.out.println("ERROR empty alumno");
			return;
		} else {

			// Objetos necesarios para la creaci�n de un documento xml
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			DOMImplementation implementation = builder.getDOMImplementation();
			Document document = implementation.createDocument(null, "alumno", null);
			document.setXmlVersion("1.0");

			// Main Node
			Element raiz = document.getDocumentElement();
			//Accedemos a las propiedades del objeto alumno y vamos creando tags xml
			
				
				
				Element nombre = document.createElement("nombre");
				Text valornombre = document.createTextNode(alumno.getNombre());
				nombre.appendChild(valornombre);
				raiz.appendChild(nombre);
				Element apellidos = document.createElement("apellidos");
				Text valorapellidos = document.createTextNode(alumno.getApellidos());
				apellidos.appendChild(valorapellidos);
				raiz.appendChild(apellidos);
				Element nacimiento = document.createElement("nacimiento");
				Text valornacimiento  = document.createTextNode(String.valueOf(alumno.getAnoNacimiento()));
				nacimiento.appendChild(valornacimiento);
				raiz.appendChild(nacimiento);
				Element direccion = document.createElement("direccion");					
				Text valorcalle   = document.createTextNode(alumno.getDireccion());
				direccion.appendChild(valorcalle);
				raiz.appendChild(direccion);
			
			
			// Generamos una fuente y un resultado para transfomar el document
			// XML a archivo XML
			Source source = new DOMSource(document);
			// Indicamos donde lo queremos almacenar
			Result result = new StreamResult(Files.newOutputStream(Paths.get(archivo))); // nombre
																				// del
																				// archivo
			Transformer transformer = TransformerFactory.newInstance()
					.newTransformer();
			transformer.transform(source, result);

			// Generamos un document DOM a partir del archivo xml
			Document document2 = builder.parse(Files.newInputStream(Paths
					.get(archivo)));
			
			// Tenemos que crear el objeto Alumno7 a mano recorriendo el DOM
			String nombreAlumno7=document2.getElementsByTagName("nombre").item(0).getFirstChild().getNodeValue();
			String apellidosAlumno7=document2.getElementsByTagName("apellidos").item(0).getFirstChild().getNodeValue();
			String nacimientoAlumno7=document2.getElementsByTagName("nacimiento").item(0).getFirstChild().getNodeValue();
			String direccionAlumno7=document2.getElementsByTagName("direccion").item(0).getFirstChild().getNodeValue();
			
			Alumno7 alrecuperado=new Alumno7(nombreAlumno7,apellidosAlumno7,new Integer(nacimientoAlumno7),direccionAlumno7);
			System.out.println(alrecuperado.toString());
		}

	}

}
