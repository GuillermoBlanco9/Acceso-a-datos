package ejercicios3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 *  @descrition Soluci�n del Ejercicio 7 utilizando el API JAXB
 *	@author Laura
 *  @date 7/4/2015
 *  @version 1.0
 *  @license GPLv3
 */

public class Ejercicio7bSol {
	
	private static final String DAT_FILE = "AlumnoJAXB.xml";

	public static void main(String[] args) throws JAXBException, IOException {		
		
		Alumno7 alumno = new Alumno7("pepe", "garcia", 1978, "calle alegria,5");
		JAXBContext context = JAXBContext.newInstance(Alumno7.class);
		Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		
		// Mostramos el documento XML generado por la salida estandar
		marshaller.marshal(alumno, System.out);
		// guardamos el objeto serializado en un documento XML
		marshaller.marshal(alumno, Files.newOutputStream(Paths.get(DAT_FILE)));
		//fos.close();
		Unmarshaller unmarshaller = context.createUnmarshaller();
		// Deserealizamos a partir de un documento XML
		Alumno7 alumnoAux = (Alumno7) unmarshaller.unmarshal(Files.newInputStream(Paths.get(
				DAT_FILE)));
		System.out
				.println("********* alumno cargado desde fichero XML***************");
		// Mostramos por linea de comandos el objeto Java obtenido
		// producto de la deserialziacion
		marshaller.marshal(alumnoAux, System.out);
	}
}


