package ejercicios3;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *  @descrition Soluci�n Ejercicio 4
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio4Sol {
	//Probar con texto.txt y con vacio.txt
	/**
	 * M�todo que solicita un nombre de archivo
	 * 
	 * @return el nombre de archivo si existe, sino finaliza el programa
	 */
	public static boolean compruebaNombre(String nombreArchivo) {

		Path p2 = Paths.get(nombreArchivo);
		boolean existe = true;
		try {

			Path fp = p2.toRealPath();

			System.out.println("Path real " + fp);
		} catch (NoSuchFileException x) {

			System.err.format("%s: no existe" + " el fichero o directorio %n",
					p2);
			existe = false;
		} catch (IOException x) {

			System.err.format("%s%n", x);
			existe = false;

		}
		return existe;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		RandomAccessFile fichero = null;
		int indice;
		int i, numLineas = 0;
		String nombreArchivo = "";
		String linea;
		try {

			System.out
					.println("Introduce un nombre de archivo del que leer");

			nombreArchivo = sc.nextLine();

			System.out.println("nombre de archivo es:" + nombreArchivo);
			if (!compruebaNombre(nombreArchivo)) {
				System.out.println("El archivo no existe");
				System.exit(-1);
			}

			// Se pide la l�nea a mostras
			System.out.print("Introduce n�mero de linea: ");
			indice = sc.nextInt();
			sc.nextLine();

			// se abre el fichero para lectura/escritura
			fichero = new RandomAccessFile(nombreArchivo, "r");

			// Calculo el n�mero total de l�neas
			while ((linea = fichero.readLine()) != null) {
				numLineas++;
			}

			if (numLineas == 0) {
				System.out.println("El archivo est� vac�o");
				System.exit(-1);
			}
			fichero.seek(0);
			// Avanzamos hasta la l�nea anterior
			for (i = 0; i < indice - 1; i++) {
				fichero.readLine();

			}
			linea = fichero.readLine();
			System.out.println("La l�nea es:" + linea);

		} catch (FileNotFoundException ex) {
			System.out.println(ex.getMessage());
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		} finally {
			try {
				if (fichero != null) {
					fichero.close();
				}
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
