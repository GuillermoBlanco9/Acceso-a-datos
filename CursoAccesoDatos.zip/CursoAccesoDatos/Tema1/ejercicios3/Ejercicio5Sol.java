package ejercicios3;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *  @descrition Soluci�n Ejercicio 5
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio5Sol {

	public static void main(String[] args) {
		Scanner escaner = new Scanner(System.in);
		SerializadorAlumno serializador=new SerializadorAlumno();
		String nombreArchivo = "";
		String nombre = "";
		String apellidos = "";
		String calle = "";
		int ano;
		int numero;
		Alumno a;

		System.out
				.println("Introduce un nombre de archivo donde almacenar los alumnos");
		nombreArchivo = escaner.nextLine();

		System.out.println("nombre de archivo es:" + nombreArchivo);
		Path ruta = Paths.get(nombreArchivo);
		if (Files.exists(ruta)) {
			System.out.println("el archivo ya existe");
			System.exit(-1);
		}

		// Solicitamos los datos del alumno
		System.out.println("Por favor introduzca un nombre de alumno");
		nombre = escaner.nextLine();
		System.out.println("Por favor introduzca los apellidos del alumno");
		apellidos = escaner.nextLine();
		System.out
				.println("Por favor introduzca el a�o de nacimiento del alumno");
		ano = escaner.nextInt();
		// Colocamos el escaner en la siguiente l�nea
		escaner.nextLine();
		System.out
				.println("Por favor introduzca el nombre de la calle del alumno");
		calle = escaner.nextLine();
		System.out
				.println("Por favor introduzca el n�mero de la calle del alumno");
		numero = escaner.nextInt();

		serializador.serializar(new Alumno(nombre, apellidos, ano, calle, numero),ruta);
		a=serializador.deserializar(ruta);
		System.out.println(a.toString());

		escaner.close();

	}

}
