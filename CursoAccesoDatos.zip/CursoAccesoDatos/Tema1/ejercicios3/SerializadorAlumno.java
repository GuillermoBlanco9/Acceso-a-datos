package ejercicios3;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
/**
 *  @descrition Soluci�n Serializador Ejercicio 5
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class SerializadorAlumno {
	public void serializar(Alumno a, Path ruta) {

		try {
			// Creamos el archivo
			// InputStream y OutputStream de java.io nos permiten trabajar byte
			// a byte
			OutputStream ostream = Files.newOutputStream(ruta);
			// FileOutputStream fs = new FileOutputStream("agenda.txt");
			ObjectOutputStream os = new ObjectOutputStream(ostream);
			// El m�todo writeObject() serializa el objeto y lo escribe en el
			// archivo
			os.writeObject(a);

			os.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Alumno deserializar(Path ruta) {
		Alumno a2 = null;

		try {
			InputStream istream = Files.newInputStream(ruta);
			// FileOutputStream fs = new FileOutputStream("agenda.txt");
			ObjectInputStream os = new ObjectInputStream(istream);

			// El m�todo readObject() recupera el objeto

			a2 = (Alumno) os.readObject();
			os.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return a2;

	}
}