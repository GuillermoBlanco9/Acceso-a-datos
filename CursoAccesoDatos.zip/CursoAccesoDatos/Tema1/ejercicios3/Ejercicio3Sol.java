package ejercicios3;

import static java.nio.file.StandardOpenOption.READ;
import static java.nio.file.StandardOpenOption.WRITE;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *  @descrition Soluci�n Ejercicio 3
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio3Sol {

	static Scanner sc = new Scanner(System.in);
	static FileChannel fc = null;

	public static void main(String[] args) {
		int numero;

		ByteBuffer out = ByteBuffer.allocate(Integer.BYTES);
		Path file = Paths.get("enteros.dat");

		try {
			fc = (FileChannel.open(file, READ, WRITE));
			mostrarFichero(); // muestra el contenido original del fichero
			
			System.out
					.print("Introduce un n�mero entero para a�adir al final del fichero: ");
			numero = sc.nextInt(); // se lee el entero a a�adir en el fichero
			out.putInt(0,numero);
			//System.out.println(out.getInt(0));
			long longitud = fc.size();
			fc.position(longitud);
			while (out.hasRemaining()) fc.write(out);
			mostrarFichero();// muestra el contenido del fichero despu�s de
								// a�adir el n�mero

		} catch (IOException x) {
			System.out.println("I/O Exception: " + x);
		}

	}

	/**
	 * M�todo para leer y mostrar por pantalla un arhcivo aleatorio con java.nio
	 */
	public static void mostrarFichero() {
		ByteBuffer in = ByteBuffer.allocate(Integer.BYTES);
		try {
			fc.position(0); // nos situamos al principio
			int nread=0;
			// Leemos hasta alcanzar el final del stream (fichero) que es cuando
			// nread sea -1
			// Leemos el contenido del ByteBuffer, hay que comprobar que tenga
			// datos pues es no bloqueante
			while ((nread != -1 && in.hasRemaining())) {
				nread = fc.read(in);
				System.out.println("N�mero de bytes le�dos: "+nread);
				/*Pasamos indice 0, sino habr�a que hacer rewind para que no est� al final del buffer
				 * y salte  java.nio.BufferUnderflowException
				 */
				if (nread!=-1) System.out.println("Entero es: "+in.getInt(0));
				//Ponemos limite a posici�n actual y posici�n a 0 para nueva lectura con buffer
				in.flip();
			}
			// LLegado este punto sabemos que hemos alcanzado el final del
			// stream(fichero)
			System.out.println("Fin de fichero");
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
}