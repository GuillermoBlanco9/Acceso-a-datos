package transparencias;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *  @descrition Clase que lee  y escribe un archivo entero de bytes con una �nica llamada a m�todo
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class ArchivosPequenosBytes {

	public static void main(String[] args) {
		Path entrada = Paths.get("entrada.txt");
		Path salida = Paths.get("salida.txt");
		//Array de bytes para leer todos los bytes del archivo
		byte[] fileArray;
		try {
			//Leemos de una vez un archivo entero de bytes utilizando java.nio
			fileArray = Files.readAllBytes(entrada);
			//Escribimos todos los bytes en el archivo salida.txt de una sola vez utilizando java.nio
			//Despu�s de ejecutar comprobar que es igual a entrada.txt
			Files.write(salida, fileArray);
		} catch (IOException io) {
			System.err.println(io);
		}
	}

}
