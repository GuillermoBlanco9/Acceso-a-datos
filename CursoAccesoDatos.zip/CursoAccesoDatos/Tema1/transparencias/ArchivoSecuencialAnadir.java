package transparencias;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import static java.nio.file.StandardOpenOption.*;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;


/**
 *  @descrition Clase que arbre un archivo en forma secuencial, con stream y buffer para a�adir l�nea al final del mismo
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class ArchivoSecuencialAnadir {

	public static void main(String[] args) {
		
		Path file = Paths.get("salida3.txt");
		Charset charset = Charset.forName("UTF-8");
		String s = "Vamos a a�adir esta l�nea al final del archivo";
		OpenOption[] options = new OpenOption[2];
		options[0] = APPEND;
		options[1] = WRITE;
		
		//Creamos un BufferedWriter de java.io de forma eficiente utilizando Files de java.nio
		try (BufferedWriter writer = Files.newBufferedWriter(file, charset,
				options)) {
			writer.newLine();
			writer.write(s, 0, s.length());
			writer.close();
			
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		}
	}

}
