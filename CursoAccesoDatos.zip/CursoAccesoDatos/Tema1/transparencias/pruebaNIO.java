package transparencias;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static java.nio.file.StandardOpenOption.*;

public class pruebaNIO {

	// Convert the string to a
	// byte array.
	public static void main(String[] args) throws IOException {
		String s = "cadena";
		Path ruta = Paths.get(".");
		byte data[] = s.getBytes();

		try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(
				ruta, APPEND))) {

			out.write(data, 0, data.length);
		} catch (IOException x) {
			System.err.println(x);
		}

	}
}
