package transparencias;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *  @descrition Clase que arbre un archivo en forma secuencial, con stream y buffer para leer las l�neas del archivo
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class ArchivoSecuencialLeer {

	public static void main(String[] args) throws IOException{
		Path file= Paths.get("entrada.txt");
		Charset charset = Charset.forName("UTF-8");
		BufferedReader reader=null;
		
		try{
			//Creamos un BuffereReader de java.io de forma eficiente utilizando Files de java.nio
			reader = Files.newBufferedReader(file, charset);		
		    String line = null;
		    while ((line = reader.readLine()) != null) {
		        System.out.println(line);
		    }
		} catch (IOException x) {
		    System.err.format("IOException: %s%n", x);
		}finally {
			//Preguntarles: �Es mejor cerrar aqu� � en el try?
			//Aqu� siempre mejor para asegurarme de liberar recursos inclusive cuando saltan excepciones
            if (reader != null) {
                reader.close();
            }
		}
	}

}
