package transparencias;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 *  @descrition Clase que lee  y escribe un archivo entero de caracteres con una �nica llamada a m�todo
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class ArchivosPequenosCaracteres {

	public static void main(String[] args) {
		Path entrada = Paths.get("entrada.txt");
		Path salida = Paths.get("salida2.txt");
		//Lista de cadenas para leer las lineas
		List<String> fileLista;
		Charset charset;
		try {
			charset = Charset.forName("UTF-8");
			//Leemos de una vez un archivo entero de caracteres utilizando java.nio
			fileLista = Files.readAllLines(entrada);
			//Escribimos una vez un archivo entero de caracteres utilizando java.nio
			Files.write(salida, fileLista,charset);
		} catch (IOException io) {
			System.err.println(io);
		}
	}

}
