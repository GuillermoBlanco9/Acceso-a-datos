package transparencias;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 *  @descrition Clase que realiza acceso aleatorio a archivo con RamdonAccessFile de java.io
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class ArchivoAleatorioIO {

	public static void main(String[] args) {
		try {
			String s = "I was here!\n";
			byte data[]=new byte[12];
            RandomAccessFile fileStore = new RandomAccessFile("entrada3.txt", "rw");
            //Cuando read returns tengo garantizado que he leido los 12 bytes porque java.io es bloqueante
            //Leo los 12 primeros bytes del archivo
            fileStore.read(data);
            // nos movemos a la posici�n especificada, al inicio del archivo
            fileStore.seek(0);

            // escribimos la cadena en la posici�n 0 (sobreescribo los 12 primeros bytes)
            fileStore.write(s.getBytes());
            long length = fileStore.length();
            //Me muevo a la �ltima posici�n del archivo (�ltimo byte)
			fileStore.seek(length-1);
			//Escribo a partir del �ltimo byte (lo sobreescribo) los 12 primero bytes del archivo que le�
			fileStore.write(data);
			fileStore.write(s.getBytes());
			//Cierro el archivo
            fileStore.close();

        } catch (IOException e) {
            e.printStackTrace();
        }


	}

}
