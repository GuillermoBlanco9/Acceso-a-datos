package transparencias;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


/**
 *  @descrition Clase que arbre un archivo en forma secuencial, con stream y buffer para escribir l�neas
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class ArchivoSecuencialEscribir {

	public static void main(String[] args) {
		Path file= Paths.get("salida3.txt");
		Charset charset = Charset.forName("UTF-8");
		String[] s=new String[3];
		s[0]= "vamos a probar a escribir una l�nea en el archivo";
		s[1]= "vamos a probar a escribir otra l�nea en el archivo";
		s[2]= "vamos a probar a escribir otra l�nea m�s en el archivo";
		//Creamos un BufferedWriter de java.io de forma eficiente utilizando Files de java.nio
		try (BufferedWriter writer = Files.newBufferedWriter(file, charset)) {
			for (int i = 0; i < s.length; i++) {
				writer.write(s[i], 0, s[i].length());
				//Escribimos nueva l�nea para separarlas
				if (i<s.length-1) writer.newLine();
			}
		    writer.close();
		} catch (IOException x) {
		    System.err.format("IOException: %s%n", x);
		}
	}

}
