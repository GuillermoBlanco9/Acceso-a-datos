package ejercicios1;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *  @descrition Soluci�n Ejercicio 1
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio1Sol {
	public static void main(String[] args) {
		
		//Si estamos en un SO Windows
		//Para el objetivo de este ejercicio no hace falta que el archivo exista
		//En las rutas windows es necesario escapar el caracter separador \\
		Path path = Paths.get("C:\\Usuarios\\pepe\\fotos");
		
		//Si estamos en un SO GNU/Linux
		//Path path = Paths.get("/home/pepe/fotos");
		
		System.out.format("toString: %s%n", path.toString());
		System.out.format("getFileName: %s%n", path.getFileName());
		System.out.format("getName(0): %s%n", path.getName(0));
		System.out.format("getNameCount: %d%n", path.getNameCount());
		System.out.format("subpath(0,2): %s%n", path.subpath(0,2));
		System.out.format("getParent: %s%n", path.getParent());
		System.out.format("getRoot: %s%n", path.getRoot());
	}

}
