package ejercicios1;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *  @descrition Soluci�n Ejercicio 2
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio2Sol {

	public static void main(String[] args) {
		Path path1 = Paths.get("/home/./pepe/fotos");
		Path path2 = Paths.get("/home/juan/../pepe/fotos");
		//El m�todo normalize es el que elimina las redundancias
		System.out.println(path1.normalize());
		System.out.println(path2.normalize());

	}

}
