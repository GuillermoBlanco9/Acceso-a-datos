package ejercicios1;

import java.nio.file.Path;
import java.nio.file.Paths;
/**
 *  @descrition Soluci�n Ejercicio 4
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio4Sol {

	public static void main(String[] args) {
		// Microsoft Windows
		Path p0 = Paths.get("C:\\Usuarios\\pepe\\fotos");
		
		//Concatena la ruta relativa pasada a la ruta original
		// El resultado es C:\Usuarios\pepe\fotos\docs
		System.out.format("%s%n", p0.resolve("docs"));
	
		
		Path p1=Paths.get("fotos");
		//Si la ruta pasada es absoluta devuelve la misma ruta
		//El resultado es C:\Usuarios\pepe
		System.out.format("%s%n", p1.resolve("C:\\Usuarios\\pepe"));
		//------------------------------------------------------------------
		
		Path p2 = Paths.get("pepe");
		Path p3 = Paths.get("juan");
		
		//Ruta del archivo juan respecto a la localizaci�n del archivo pepe
		//El resultado es ..\juan
		Path p2_to_p3 = p2.relativize(p3);
		System.out.format("%s%n", p2_to_p3);
		
		//Ruta del archivo pepe respecto a la localizaci�n del archivo juan
		// El resultado es ..\pepe
		Path p3_to_p2 = p3.relativize(p2);
		System.out.format("%s%n", p3_to_p2);
		
		
		Path p4 = Paths.get("Usuarios");
		Path p5 = Paths.get("Usuarios\\juan\\docs");
		
		//Ruta de Usuarios\juan\docs respecto a la localizaci�n Usuarios
		//El resultado es juan\docs
		Path p4_to_p5 = p4.relativize(p5);
		System.out.format("%s%n", p4_to_p5);
		
		//Ruta de Usuarios respecto a la localizaci�n Usuarios\juan\docs
		//El resultado es ..\..
		Path p5_to_p4 = p5.relativize(p4);
		System.out.format("%s%n",p5_to_p4);

	}

}
