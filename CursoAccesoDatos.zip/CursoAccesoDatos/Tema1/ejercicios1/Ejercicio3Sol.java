package ejercicios1;

import java.io.IOException;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
/**
 *  @descrition Soluci�n Ejercicio 3
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio3Sol {
	/*
	 * Para ejecutar Bot�n derecho --> Run as --> Run Configurations --> En
	 * argumentos escribir entrada.txt. Es necesario para probar toAbsolutePath
	 */
	public static void main(String[] args) {

		// Primer m�todo toUri
		Path p1 = Paths.get("entrada.txt");
		/*
		 * El resultado es file:///D:/workspace/CursoAccesoDatos/entrada.txt
		 * Convierte en una URI que el navegador puede interpretar
		 */
		System.out.format("%s%n", "URI " + p1.toUri());

		// -------------------------------------------------------------------------------

		/*
		 * Segundo m�todo toAbsolutePath
		 * 
		 * toAbsolutePath method convierte una ruta en una ruta absoluta. Si la
		 * ruta pasada ya es absoluta devuelve el mismo objeto Path. Si es
		 * relativa, lo que hace es anteponer la ruta absoluta hasta el
		 * directorio actual. Es muy �til para procesar nombres de archivo
		 * proporcionados por el usuario. Este m�todo no requiere que los
		 * archivos existan realmente.
		 */

		if (args.length < 1) {
			System.out.println("debes pasar un nombre de archivo como argumento");
			System.exit(-1);
		}

		// Convertimos la cadena de entrada en un objeto Path.
		Path inputPath = Paths.get(args[0]);
		Path fullPath = inputPath.toAbsolutePath();
		// El resulatdo es D:\workspace\CursoAccesoDatos\entrada.txt
		System.out.println("Path absoluto " + fullPath);

		// -------------------------------------------------------------------------------
		// Tercer m�todo toRealPath
		/*
		 * toRealPath method devuelve la ruta real para un archivo existente.
		 * Realiza las siguientes operaciones: Si se le pasa true como
		 * argumento, resuelve los posibles enlaces simb�licos de la ruta. Si la
		 * ruta es relativa, devuelve una ruta absoluta. Elimina informaci�n
		 * redundante de la ruta. Lanza una excepci�n si el archivo no existe o
		 * no se puede acceder
		 */
		Path p2 = Paths.get("./entrada.txt"); //Tambi�n vale "entrada.txt", probar a poer "noxiste.txt"
		try {

			Path fp = p2.toRealPath();
			// El resultado es D:\workspace\CursoAccesoDatos\entrada.txt
			System.out.println("Path real " + fp);
		} catch (NoSuchFileException x) {
			// Si el archivo no existe
			System.err.format("%s: no existe" + " el fichero o directorio %n",
					p2);

		} catch (IOException x) {
			// Otros errores posibles al acceder al archivo
			System.err.format("%s%n", x);

		}

	}
}
