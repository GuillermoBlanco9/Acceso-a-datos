package ejercicios1;

import java.io.IOException;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
/**
 *  @descrition Clase para Ejercicio 3
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio3 {

	/*
	 * Para ejecutar Bot�n derecho --> Run as --> Run Configurations --> En
	 * argumentos escribir entrada.txt. Es necesario para probar toAbsolutePath
	 */
	public static void main(String[] args) {

		// Primer m�todo toUri
		Path p1 = Paths.get("entrada.txt");

		System.out.format("%s%n", "URI " + p1.toUri());

		// -------------------------------------------------------------------------------

		// Segundo m�todo toAbsolutePath

		if (args.length < 1) {
			System.out
					.println("debes pasar un nombre de archivo como argumento");
			System.exit(-1);
		}

		Path inputPath = Paths.get(args[0]);
		Path fullPath = inputPath.toAbsolutePath();

		System.out.println("Path absoluto " + fullPath);

		// -------------------------------------------------------------------------------

		// Tercer m�todo toRealPath

		Path p2 = Paths.get("./entrada.txt");
		try {

			Path fp = p2.toRealPath();

			System.out.println("Path real " + fp);
		} catch (NoSuchFileException x) {

			System.err.format("%s: no existe" + " el fichero o directorio %n",
					p2);

		} catch (IOException x) {

			System.err.format("%s%n", x);

		}

	}

}
