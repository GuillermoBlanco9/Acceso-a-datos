package ejercicios1;

import java.nio.file.Path;
import java.nio.file.Paths;
/**
 *  @descrition Soluci�n Ejercicio 5
 *	@author Laura
 *  @date 26/3/2015
 *  @version 1.0
 *  @license GPLv3
 */
public class Ejercicio5Sol {

	public static void main(String[] args) {
		Path path = Paths.get("Usuarios\\juan\\fotos");
		Path otherPath = Paths.get("C:\\Usuarios\\juan\\fotos");
		Path beginning = Paths.get("Usuarios");
		Path ending = Paths.get("fotos");

		if (path.equals(otherPath)) {
			System.out.println("Las rutas son iguales");
		}
		if (path.startsWith(beginning)) {
			System.out.println("La ruta comienza por \\Usuarios");
		}
		if (path.endsWith(ending)) {
			System.out.println("La ruta acaba por fotos");
		}

	}

}
